#fix me.. but for now lets just pass the data back..

def compress(data):
    return data

def decompress(data):
    return data
