
def getpwuid():
    pass
