a = 1

def f():
    a = a+1

f()
